export const metadata = { title: "Zyklus Küche", description: "Zyklusgerechte Ernährung" };
export default function RootLayout({ children }) {
  return (
    <html lang="de">
      <body style={{ margin: 0, padding: 0, background: "#F7F3EE" }}>{children}</body>
    </html>
  );
}
